import getFlexibleStyled from 'react-native-styled-px2dp';

const { styled } = getFlexibleStyled({
  designWidth: 400,
  designHeight: 640,
});

export default styled;
